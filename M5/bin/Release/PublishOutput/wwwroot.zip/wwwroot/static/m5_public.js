document.write('<script type="text/javascript" src="/static/js/baseControl.js"></script>');
document.write('<script type="text/javascript" src="/static/js/frame.js"></script>');
document.write('<script type="text/javascript" src="/static/js/config.js"></script>');
document.write('<script src="/static/js/dialog.js"></script>');
document.write('<script src="/static/js/jquery.validate.min.js"></script>');
document.write('<script src="/static/js/messages_zh.js"></script>');
document.write('<script src="/static/js/validate-methods.js"></script>');
