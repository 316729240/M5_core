$M.config.webPath = "/";
$M.config.sysAppPath = "/manage/app/system/";
$M.config.appPath = "/manage/app/";
$M.config.operationTimeDelay = 100;